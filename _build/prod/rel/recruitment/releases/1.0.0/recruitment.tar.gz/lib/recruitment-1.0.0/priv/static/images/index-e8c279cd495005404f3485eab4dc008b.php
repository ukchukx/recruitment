<?php 
die(header('location: ../../recruit')); 
?>