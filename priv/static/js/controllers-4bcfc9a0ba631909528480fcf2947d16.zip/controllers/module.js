
//var framework="frameworkmlm";
//(function(){
  'use strict';
  var module = angular.module('nps', ['ngRoute','ngSanitize','angularUtils.directives.dirPagination','ngCookies']);
